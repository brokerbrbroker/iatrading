/// <reference types="vite/client" />

interface Window {
  pixelId?: string;
}